import { render, screen } from '@testing-library/react';
import App from './App';

test('renders valtech_ link', () => {
  render(<App />);
  const linkElement = screen.getByText(/valtech_/i);
  expect(linkElement).toBeInTheDocument();
});

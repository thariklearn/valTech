import React, { Component, Fragment } from "react";

const Helpers = {
    isEmpty: value => {
        return (
          value === undefined ||
          value === null ||
          value === 'null' ||
          value === 'undefined' ||
          (typeof value === "object" && Object.keys(value).length === 0) ||
          (typeof value === "string" && value.trim().length === 0)
        );
      },
      truncate(string, length) {
        if (!this.isEmpty(string)) {
          if (string.length > length) {
            return string.substring(0, length) + "...";
          } else {
            return string;
          }
        }
      },
     isMobile: function () {
        return (!this.isEmpty(this.isAndroid() || this.isBlackBerry() || this.isIOS() || this.isOpera() || this.isWindows()));
     },
     isAndroid: function () {
        return navigator.userAgent.match(/Android/i);
      },
      isBlackBerry: function () {
        return navigator.userAgent.match(/BlackBerry/i);
      },
      isIOS: function () {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
      },
      isOpera: function () {
        return navigator.userAgent.match(/Opera Mini/i);
      },
      isWindows: function () {
        return navigator.userAgent.match(/IEMobile/i);
      },
      
}

export default Helpers;
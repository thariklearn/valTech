var data = [
    {
        "country":"ITALY",
        "city":"VENICE",
        "description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
        "image":"https://media.istockphoto.com/photos/venice-picture-id491391396?k=20&m=491391396&s=612x612&w=0&h=x_DafAdt7Bx_QtZ0oDdzkYC3LmFeXK-iftLdWl6gX8I=",
        "col":"6"
    },
    {
        "country":"GERMANY",
        "city":"BERLIN",
        "description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
        "image":"https://images.unsplash.com/photo-1528728329032-2972f65dfb3f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8YmVybGlufGVufDB8fDB8fA%3D%3D&w=1000&q=80",
        "col":"3"
    },
    {
        "country":"SPAIN",
        "city":"BARCELONA",
        "description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
        "image":"https://static.dw.com/image/60441943_101.jpg",
        "col":"3"
    },
    {
        "country":"FRANCE",
        "city":"PARIS",
        "description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
        "image":"https://media.cntraveler.com/photos/5cf96a9dd9fb41f17ed08435/master/pass/Eiffel%20Tower_GettyImages-1005348968.jpg",
        "col":"3"
    },
    {
        "country":"NETHERLANDS",
        "city":"AMSTERDAM",
        "description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
        "image":"https://totalenergies.com/sites/g/files/nytnzq121/files/styles/w_1110/public/images/2021-10/pays-bas_0.jpg?itok=CZbMqnbx",
        "col":"3"
    },
    {
        "country":"UNITED KINGDOM",
        "city":"LONDON",
        "description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
        "image":"https://london.ac.uk/sites/default/files/styles/max_1300x1300/public/2018-10/london-aerial-cityscape-river-thames_1.jpg?itok=6LenFxuz",
        "col":"6"
    },
]

export default data;
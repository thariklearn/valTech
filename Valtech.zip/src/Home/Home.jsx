import React ,{useState,useEffect} from 'react';
import Banner from './Banner';
import Helpers from '../Shared/custom';
import data  from  '../Shared/data';
import './style.css'


function Home() {

    const [dataset, setDataset] = useState([]);

    useEffect(() => {
        setDataset(data);
        return []
    }, [data])

    return (
           <React.Fragment>
               <div className="container">
                    <Banner />
                    <div className="py-3">
                            <div className="row">
                                {!Helpers.isEmpty(dataset) &&

                                    dataset.map((list,i)=>(
                                        <div className={`col-lg-${list.col} mb-3 mb-lg-0 mt-3`} key={`div`+i}>
                                                <div className="hover hoverable text-white rounded"><img src={list.image} alt={list.city+","+list.country} />
                                                <div className="hover-overlay"></div>
                                                <div className="hoverable-content px-5 py-4">
                                                    <h3 className="hoverable-title text-uppercase font-weight-bold mb-0"> 
                                                        <p className="font-14 m-0">{list.country}</p>
                                                        <span className="font-weight-light">{list.city}</span>
                                                    </h3>
                                                    <p className="hoverable-description text-uppercase mb-0">
                                                        {(list.col == '6' && !Helpers.isMobile()) ? Helpers.truncate(list.description,100) :Helpers.truncate(list.description,40)  }
                                                    </p>
                                                    <div className="hoverable-button text-uppercase mb-0">
                                                        <div className="mt-1"> 
                                                            <button role="button" aria-pressed="false" className="btn btn-white exploreBtn">Explore More </button>
                                                        </div>
                                                    </div>
                                            </div>
                                            </div>
                                        </div>
                                    ))
                                }
                        </div>
                     </div>
                </div>
          </React.Fragment>
  
    )
}

export default Home

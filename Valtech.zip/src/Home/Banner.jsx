import React from 'react';

function Banner() {
    return (
        <div className="row">
            <div className="container-banner mt-5">
                <img src="https://cdn.pixabay.com/photo/2017/11/08/13/31/nature-2930457_960_720.jpg" alt="valtech banner"/>
                <div className="centered">
                    <p>FRONT-END</p>
                    <h1>valtech_</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                </div>
            </div>
        </div>
    )
}

export default Banner
